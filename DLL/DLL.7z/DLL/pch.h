﻿// pch.h
#ifndef PCH_H
#define PCH_H

// 添加预编译头文件包含
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#endif // PCH_H
